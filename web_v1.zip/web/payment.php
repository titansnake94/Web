<?php
    session_start();
    require('./includes/lists.php');
    init_error();

    if (empty($_POST) && !isset($_GET['err'])){
        // redirect to index page
        header("Location: index.php");
    }

    // Get infos from Session
    $product_id = $_SESSION['product']['id'];
    $product_name = $_SESSION['product']['name'];
    $product_price = $_SESSION['product']['price'];
    $product_description = $_SESSION['product']['description'];

    if (!empty($_POST)){
        
        // Get Infos from Delivery page
        $qty = $_POST['inputQty'];
        $total = $qty * $product_price + 10;
        $recip_name = $_POST['inputName'];
        $address = $_POST['inputAddress'];
        $city = $_POST['inputCity'];
        $zip = $_POST['inputZip'];
        $delivery_date = $_POST['inputDate'];
        $delivery_time = $_POST['inputTime'];
        $msg = $_POST['inputMsg'];

        // Set session variables
        $_SESSION['product']['qty'] = $qty;
        $_SESSION['product']['total'] = $total;
        $_SESSION['delivery']['name'] = $recip_name;
        $_SESSION['delivery']['address'] = $address;
        $_SESSION['delivery']['city'] = $city;
        $_SESSION['delivery']['zip'] = $zip;
        $_SESSION['delivery']['date'] = $delivery_date;
        $_SESSION['delivery']['time'] = $delivery_time;
        $_SESSION['delivery']['msg'] = $msg;
    }

    /*=== Check delivery information ===*/

    // 1. zip code check
    $country_code="UK";

    $ZIPREG=array(
        "US"=>"^\d{5}([\-]?\d{4})?$",
        "UK"=>"^(GIR|[A-Z]\d[A-Z\d]??|[A-Z]{2}\d[A-Z\d]??)[ ]??(\d[A-Z]{2})$",
        "DE"=>"\b((?:0[1-46-9]\d{3})|(?:[1-357-9]\d{4})|(?:[4][0-24-9]\d{3})|(?:[6][013-9]\d{3}))\b",
        "CA"=>"^([ABCEGHJKLMNPRSTVXY]\d[ABCEGHJKLMNPRSTVWXYZ])\ {0,1}(\d[ABCEGHJKLMNPRSTVWXYZ]\d)$",
        "FR"=>"^(F-)?((2[A|B])|[0-9]{2})[0-9]{3}$",
        "IT"=>"^(V-|I-)?[0-9]{5}$",
        "AU"=>"^(0[289][0-9]{2})|([1345689][0-9]{3})|(2[0-8][0-9]{2})|(290[0-9])|(291[0-4])|(7[0-4][0-9]{2})|(7[8-9][0-9]{2})$",
        "NL"=>"^[1-9][0-9]{3}\s?([a-zA-Z]{2})?$",
        "ES"=>"^([1-9]{2}|[0-9][1-9]|[1-9][0-9])[0-9]{3}$",
        "DK"=>"^([D-d][K-k])?( |-)?[1-9]{1}[0-9]{3}$",
        "SE"=>"^(s-|S-){0,1}[0-9]{3}\s?[0-9]{2}$",
        "BE"=>"^[1-9]{1}[0-9]{3}$"
    );

    if ($ZIPREG[$country_code]) {
        if (!preg_match("/".$ZIPREG[$country_code]."/i", $_SESSION['delivery']['zip'])){
            $_SESSION['delivery_error'] = true;
            $_SESSION['delivery_error_msg'] = "Postal code '$zip' is not valid, please try again!";
            header("Location: delivery.php?id=$product_id");
        }
    }

    // date check
    $today = date("Y-m-d");
    if($_SESSION['delivery']['date'] < $today) {
        $_SESSION['delivery_error'] = true;
        $_SESSION['delivery_error_msg'] = "Delivery date '$delivery_date' is set less than today, please try again!";
        header("Location: delivery.php?id=$product_id");
    }

    function init_error() {
        $_SESSION['delivery_error'] = false;
        $_SESSION['delivery_error_msg'] = '';
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Payment</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="./assets/bootstrap/css/bootstrap.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" type="text/css" href="./assets/custom.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/">Florists</a>
        </div>
    </nav>
    <div class="container main p-5 mt-5 mb-5">
        <?php if(isset($_SESSION['payment_error']) && $_SESSION['payment_error'] == true) { ?>
        <div class="alert alert-dismissible alert-warning">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <h4 class="alert-heading">Error!</h4>
            <p class="mb-0"><?php echo $_SESSION['payment_error_msg']; ?></p>
        </div>
        <?php } ?>
        <div class="row">
            <div class="col-md-12 product-list">
                <table class="table border-bottom">
                    <thead>
                        <tr>
                            <th scope="col">Bouquet</th>
                            <th scope="col">Description</th>
                            <th scope="col">Price</th>
                            <th scope="col">Qty</th>
                            <th scope="col">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <img src="./images/<?php echo $product_name; ?>" width="100" alt="" srcset="">
                            </td>
                            <td><?php echo $product_description; ?></td>
                            <td>£<?php echo $product_price; ?></td>
                            <td><?php echo $_SESSION['product']['qty']; ?></td>
                            <td>£<?php echo $_SESSION['product']['total']; ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-6">
                <div class="delivery-information p-3 border">
                    <h3 class="pb-4">Delivery Information:</h3>
                    <p>
                        <span class="info-title">Recipients name:</span>
                        <span class="text-primary"><?php echo $_SESSION['delivery']['name']; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Delivery Address:</span>
                        <span class="text-primary"><?php echo $_SESSION['delivery']['address'] . ', ' . $_SESSION['delivery']['city'];; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Zip Code:</span>
                        <span class="text-primary"><?php echo $_SESSION['delivery']['zip'];; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Delivery Date & Time:</span>
                        <span class="text-primary"><?php echo $_SESSION['delivery']['date'] . ', ' . $_SESSION['delivery']['time'];; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Message to Recipient:</span>
                        <span class="text-primary"><?php echo $_SESSION['delivery']['msg'];; ?></span>
                    </p>

                    <a href="./delivery.php?id=<?php echo $product_id ?>" type="button" class="btn btn-danger mt-3">Back to Delivery Page</a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="payment-information p-3 border">
                    <h3 class="pb-4">Payment Information:</h3>
                    <form method="post" action="./order.php">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="cardName">Credit Card Name *</label>
                                <select class="custom-select" id="cardName" name="cardName">
                                    <option selected="">Choose Card</option>
                                    <option value="visa">Visa</option>
                                    <option value="mastercard">mastercard</option>
                                    <option value="amex">amex</option>
                                    <option value="discover">discover</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="cardAdress">Credit Card Address *</label>
                                <input type="text" class="form-control" id="cardAdress" name="cardAdress" placeholder="Enter Card Address" value="<?php if(isset($_SESSION['card'])) { echo $_SESSION['card']['address'];} ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="cardNumber">Credit Card Number *</label>
                            <input type="text" class="form-control" id="cardNumber" name="cardNumber" placeholder="Enter Card Number" value="<?php if(isset($_SESSION['card'])) { echo $_SESSION['card']['number'];} ?>" required>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="expireDate">Expire Date *</label>
                                <input type="date" class="form-control" id="expireDate" name="expireDate" value="<?php if(isset($_SESSION['card'])) { echo $_SESSION['card']['expireDate']; } ?>" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="securityCode">Security Code *</label>
                                <input type="text" class="form-control" id="securityCode" name="securityCode" placeholder="123" value="<?php if(isset($_SESSION['card'])) { echo $_SESSION['card']['securityCode'];} ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="phoneNumber">Contact Phone Number *</label>
                            <input type="text" class="form-control" id="phoneNumber" name="phoneNumber" placeholder="Enter Phone Number" value="<?php if(isset($_SESSION['phoneNumber'])) {echo $_SESSION['phoneNumber'];} ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address *</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" value="<?php if(isset($_SESSION['email'])) { echo $_SESSION['email']; } ?>" required>
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg">Place Order</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="./assets/jquery/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="./assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>