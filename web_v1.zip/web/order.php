<?php
    session_start();

    $_SESSION['payment_error'] = false;
    $_SESSION['payment_error_msg'] = '';

    // Get Order Information from Session
    $product_id = $_SESSION['product']['id'];
    $product_name = $_SESSION['product']['name'];
    $product_price = $_SESSION['product']['price'];
    $product_description = $_SESSION['product']['description'];
    $product_qty = $_SESSION['product']['qty'];
    $total = $_SESSION['product']['total'];

    // Get Deliver detail from Session
    $recip_name = $_SESSION['delivery']['name'];
    $address = $_SESSION['delivery']['address'];
    $city = $_SESSION['delivery']['city'];
    $zip = $_SESSION['delivery']['zip'];
    $delivery_date = $_SESSION['delivery']['date'];
    $delivery_time = $_SESSION['delivery']['time'];
    $msg = $_SESSION['delivery']['msg'];

    // Get Payment detail from payment page
    $card_name = $_POST['cardName'];
    $card_address = $_POST['cardAdress'];
    $card_number = $_POST['cardNumber'];
    $expire_date = $_POST['expireDate'];
    $security_code = $_POST['securityCode'];
    $phone_number = $_POST['phoneNumber'];
    $email = $_POST['email'];

    // Set session for card info
    $_SESSION['card']['name'] = $card_name;
    $_SESSION['card']['address'] = $card_address;
    $_SESSION['card']['number'] = $card_number;
    $_SESSION['card']['expireDate'] = $expire_date;
    $_SESSION['card']['securityCode'] = $security_code;
    $_SESSION['phoneNumber'] = $phone_number;
    $_SESSION['email'] = $email;

    // validate card number
    function validatecard($card_number){
        $number = str_replace(' ', '', $card_number);
        $cardtype = array(
            "visa"       => "/^4[0-9]{12}(?:[0-9]{3})?$/",
            "mastercard" => "/^5[1-5][0-9]{14}$/",
            "amex"       => "/^3[47][0-9]{13}$/",
            "discover"   => "/^6(?:011|5[0-9]{2})[0-9]{12}$/",
        );

        if (preg_match($cardtype['visa'], $number)){
            return 'visa';
        } else if (preg_match($cardtype['mastercard'], $number)) {
            return 'mastercard';
        } else if (preg_match($cardtype['amex'], $number)) {
            return 'amex';
        } else if (preg_match($cardtype['discover'], $number)) {
            return 'discover';
        } else {
            return false;
        }
    }

    if(!validatecard($card_number)){
        $_SESSION['payment_error'] = true;
        $_SESSION['payment_error_msg'] = "Card Number is not Valid.";
        header("Location: payment.php?err=1");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Order</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="./assets/bootstrap/css/bootstrap.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" type="text/css" href="./assets/custom.css">
</head>
<body style="background-color: #eee;">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/">Florists</a>
        </div>
    </nav>

    <div class="container container mt-5 p-5 border" style="background-color: #fff;">
        <div class="row">
            <div class="col-md-12 product-list">
                <h3>Order Detail:</h3>
                <table class="table border-top-0 mt-3 border">
                    <thead>
                        <tr>
                            <th scope="col">Bouquet</th>
                            <th scope="col">Description</th>
                            <th scope="col">Price</th>
                            <th scope="col">Qty</th>
                            <th scope="col">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <img src="./images/<?php echo $product_name; ?>" width="100" alt="" srcset="">
                            </td>
                            <td><?php echo $product_description; ?></td>
                            <td>£<?php echo $product_price; ?></td>
                            <td><?php echo $product_qty; ?></td>
                            <td>£<?php echo $total; ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-12">
                <h3>Delivery Detail:</h3>
                <div class="delivery-information p-3 mt-3 border">
                    <p>
                        <span class="info-title">Recipients name:</span>
                        <span class="text-primary"><?php echo $recip_name; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Delivery Address:</span>
                        <span class="text-primary"><?php echo $address . ', ' . $city; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Zip Code:</span>
                        <span class="text-primary"><?php echo $zip; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Delivery Date & Time:</span>
                        <span class="text-primary"><?php echo $delivery_date . ', ' . $delivery_time; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Message to Recipient:</span>
                        <span class="text-primary"><?php echo $msg; ?></span>
                    </p>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-12">
                <h3>Payment Detail:</h3>
                <div class="delivery-information p-3 mt-3 border">
                    <p>
                        <span class="info-title">Card Name:</span>
                        <span class="text-primary"><?php echo $card_name; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Card Address:</span>
                        <span class="text-primary"><?php echo $card_address; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Card Number:</span>
                        <span class="text-primary"><?php echo $card_number; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Expire Date:</span>
                        <span class="text-primary"><?php echo $expire_date; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Security Code:</span>
                        <span class="text-primary"><?php echo $security_code; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Phone Number:</span>
                        <span class="text-primary"><?php echo $phone_number; ?></span>
                    </p>
                    <p>
                        <span class="info-title">Email:</span>
                        <span class="text-primary"><?php echo $email; ?></span>
                    </p>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-12">
                <h3>Internal Use Only:</h3>
                <div class="delivery-information p-3 mt-3 border">
                    <div class="row pt-2">
                        <p for="orderStatus" class="col-sm-2 info-title">Processed by:</p>
                        <p for="orderStatus" class="col-sm-8 border-bottom">&nbsp;</p>
                    </div>
                    <div class="row">
                        <p for="orderStatus" class="col-sm-2 info-title">Date:</p>
                        <p for="orderStatus" class="col-sm-8 border-bottom">&nbsp;</p>
                    </div>
                    <div class="row pt-2">
                        <p for="orderStatus" class="col-sm-2 info-title">Delivered by:</p>
                        <p for="orderStatus" class="col-sm-8 border-bottom">&nbsp;</p>
                    </div>
                    <div class="row">
                        <p for="orderStatus" class="col-sm-2 info-title">Date:</p>
                        <p for="orderStatus" class="col-sm-8 border-bottom">&nbsp;</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>