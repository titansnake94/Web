<?php
// Array of bouquet descriptions
$description[1] = "White Bouquet";
$description[2] = "Bright Bouquet";
$description[3] = "Pinks Bouquet";
$description[4] = "White Basket";
$description[5] = "12 Rose Bouquet";
$description[6] = "Yellow Bouquet";
$description[7] = "Mixed Bouquet";
$description[8] = "Blue Bouquet";
$description[9] = "Orchid";
$description[10] = "Summer Basket";
$description[11] = "Yellow Vase";
$description[12] = "Orange Vase";

// Array of bouquet prices
$price[1] = 24.95;
$price[2] = 17.99;
$price[3] = 17.95;
$price[4] = 25.50;
$price[5] = 60.00;
$price[6] = 18.50;
$price[7] = 21.75;
$price[8] = 23.45;
$price[9] = 19.95;
$price[10] = 23.50;
$price[11] = 45.00;
$price[12] = 43.00;

?>