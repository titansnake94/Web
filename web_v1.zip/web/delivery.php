<?php
    // Start PHP session
    session_start();
    require('./includes/lists.php');

    // Get Selected Product ID from index page
    $product_id = $_GET['id'];

    // Get Price and Description from list.php
    $price = $price[$product_id];
    $description = $description[$product_id];

    // Set Session variables
    $_SESSION['product']['id'] = $product_id;
    $_SESSION['product']['name'] = $product_id . '.jpg';
    $_SESSION['product']['price'] = $price;
    $_SESSION['product']['description'] = $description;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Delivery</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="./assets/bootstrap/css/bootstrap.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" type="text/css" href="./assets/custom.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/">Florists</a>
        </div>
    </nav>

    <div class="container main p-5 mt-5 mb-5">
        <?php if(isset($_SESSION['delivery_error']) && $_SESSION['delivery_error'] == true) { ?>
        <div class="alert alert-dismissible alert-warning">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <h4 class="alert-heading">Error!</h4>
            <p class="mb-0"><?php echo $_SESSION['delivery_error_msg']; ?></p>
        </div>
        <?php } ?>
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="product-img border p-1 mr-5">
                    <img src="./images/<?php echo $product_id; ?>.jpg" alt="" srcset="" width="100%">
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="product-info">
                    <h1>Bouquet</h1>
                    <h3 class="text-primary pb-3">£<?php echo $price; ?></h3>
                    <p><?php echo $description ?></p>
                </div>
                <hr>
                <form method="post" action="./payment.php">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputName">Recipient name *</label>
                            <input type="text" class="form-control" id="inputName" name="inputName" placeholder="Mark" value="<?php if(isset($_SESSION['delivery'])) { echo $_SESSION['delivery']['name'];} ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputQty">Qty *</label>
                            <input type="number" class="form-control" id="inputQty" name="inputQty" min="1" value="<?php if(isset($_SESSION['delivery'])) { echo $_SESSION['product']['qty'];} else { echo 1; } ?>" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputAddress">Address *</label>
                            <input type="text" class="form-control" id="inputAddress" name="inputAddress" placeholder="1234 Main St" value="<?php if(isset($_SESSION['delivery'])) { echo $_SESSION['delivery']['address'];} ?>" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="inputCity">City *</label>
                            <input type="text" class="form-control" id="inputCity" name="inputCity" placeholder="London" value="<?php if(isset($_SESSION['delivery'])) { echo $_SESSION['delivery']['city'];} ?>" required>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="inputZip">Zip *</label>
                            <input type="text" class="form-control" id="inputZip" name="inputZip" value="<?php if(isset($_SESSION['delivery'])) { echo $_SESSION['delivery']['zip'];} ?>" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputDate">Delivery Date</label>
                            <input type="date" class="form-control" id="inputDate" name="inputDate" value="<?php if(isset($_SESSION['delivery'])) { echo $_SESSION['delivery']['date'];} ?>">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputTime">Delivery Time</label>
                            <input type="time" class="form-control" id="inputTime" name="inputTime" value="<?php if(isset($_SESSION['delivery'])) { echo $_SESSION['delivery']['time'];} ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputMsg">Message to Recipient</label>
                        <textarea class="form-control" id="inputMsg" name="inputMsg" rows="3"><?php if(isset($_SESSION['delivery'])) { echo $_SESSION['delivery']['msg'];} ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg float-right">Submit</button>
                </form>
            </div>
        </div>
    </div>
    <!-- jQuery -->
    <script src="./assets/jquery/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="./assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>