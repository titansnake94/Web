<?php require('./includes/lists.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Florist</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="./assets/bootstrap/css/bootstrap.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" type="text/css" href="./assets/custom.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/">Florists</a>
        </div>
    </nav>

    <div class="container main p-5 mt-5 mb-5">
        <div class="row">
        <?php
            /*=== Scan flower images from directory ===*/
            $dir    = './images';
            $files = scandir($dir);
            $loop = 1;

            /*=== List All flowers ===*/
            foreach($files as $file) {
                if(strrpos($file, '.jpg')){
                    $img_url = './images/' . $file;
                    $id = substr($file, 0, strpos($file, '.'));
        ?>
            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <a href="./delivery.php?id=<?php echo $id; ?>" class="product">
                    <!-- Card Start -->
                    <div class="card mb-3">
                        <img src="<?php echo $img_url; ?>" alt="Card image" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title text-primary">£<?php echo $price[$id]; ?></h5>
                            <p class="card-text"><?php echo $description[$id]; ?></p>
                        </div>
                    </div>
                </a>
            </div>
        <?php
                $loop++;
                }
            }
        ?>
        </div>
    </div>
    <!-- jQuery -->
    <script src="./assets/jquery/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="./assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>